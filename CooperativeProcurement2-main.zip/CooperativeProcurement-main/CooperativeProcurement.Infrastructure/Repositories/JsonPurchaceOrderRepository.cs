using System.Text.Json;
using CooperativeProcurement.Core.Interfaces;
using CooperativeProcurement.Core.Models;

namespace CooperativeProcurement.Infrastructure.Repositories;

public class JsonPurchaseOrderRepository : IPurchaseOrderRepository
{
    private readonly string _filePath = "orders.json";
    private readonly List<PurchaseOrder> _orders = [];

    public JsonPurchaseOrderRepository()
    {
        if (File.Exists(this._filePath))
        {
            string json = File.ReadAllText(this._filePath);
            this._orders = JsonSerializer.Deserialize<List<PurchaseOrder>>(json) ?? [];
        }
    }

    public Task<IEnumerable<PurchaseOrder>> GetAllAsync() => Task.FromResult<IEnumerable<PurchaseOrder>>(this._orders);

    public Task<PurchaseOrder?> GetByIdAsync(Guid id) => Task.FromResult(this._orders.FirstOrDefault(o => o.Id == id));

    public Task<PurchaseOrder> CreateAsync(PurchaseOrder order)
    {
        this._orders.Add(order);
        Save();
        return Task.FromResult(order);
    }

    public Task UpdateAsync(PurchaseOrder order)
    {
        PurchaseOrder? existing = this._orders.FirstOrDefault(o => o.Id == order.Id);
        if (existing != null)
        {
            _ = this._orders.Remove(existing);
            this._orders.Add(order);
            Save();
        }

        return Task.CompletedTask;
    }

    public Task DeleteAsync(Guid id)
    {
        PurchaseOrder? order = this._orders.FirstOrDefault(o => o.Id == id);
        if (order != null)
        {
            _ = this._orders.Remove(order);
            Save();
        }

        return Task.CompletedTask;
    }

    private void Save()
    {
        string json = JsonSerializer.Serialize(this._orders, new JsonSerializerOptions { WriteIndented = true });
        File.WriteAllText(this._filePath, json);
    }
}
