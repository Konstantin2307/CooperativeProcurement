using CooperativeProcurement.Core.Interfaces;
using CooperativeProcurement.Core.Models;
using CooperativeProcurement.Infrastructure.Repositories;
using Microsoft.AspNetCore.Mvc;

namespace CooperativeProcurement.WebAPI.Controllers;

[Route("api/[controller]")]
[ApiController]
public sealed class PurchaseOrdersController : ControllerBase
{
    private readonly IPurchaseOrderRepository _repository;

    public PurchaseOrdersController()
    {
        this._repository = new JsonPurchaseOrderRepository();
    }

    [HttpGet]
    public async Task<ActionResult<IEnumerable<PurchaseOrder>>> GetAll()
    {
        IEnumerable<PurchaseOrder> orders = await this._repository.GetAllAsync();
        return Ok(orders);
    }

    [HttpGet("{id}")]
    public async Task<ActionResult<PurchaseOrder>> GetById(Guid id)
    {
        PurchaseOrder? order = await this._repository.GetByIdAsync(id);
        return order == null ? (ActionResult<PurchaseOrder>)NotFound() : (ActionResult<PurchaseOrder>)Ok(order);
    }

    [HttpPost]
    public async Task<ActionResult<PurchaseOrder>> Create([FromBody] PurchaseOrder order)
    {
        PurchaseOrder createdOrder = await this._repository.CreateAsync(order);
        return CreatedAtAction(nameof(GetById), new { id = createdOrder.Id }, createdOrder);
    }
}
