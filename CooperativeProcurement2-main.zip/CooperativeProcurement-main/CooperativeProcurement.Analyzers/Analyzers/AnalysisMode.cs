namespace CooperativeProcurement.Analyzers.Analyzers;

public enum AnalysisMode
{
    Syntactic,
    Semantic
}
