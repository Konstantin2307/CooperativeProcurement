﻿using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp;

namespace CooperativeProcurement.Analyzers.Services
{
    public class SyntaxTreeWalker : CSharpSyntaxWalker
    {
        public int NodeCount { get; private set; }
        public int TokenCount { get; private set; }

        public override void Visit(SyntaxNode? node)
        {
            NodeCount++;
            base.Visit(node);
        }

        public override void VisitToken(SyntaxToken token)
        {
            if (!token.IsKind(SyntaxKind.None))
                TokenCount++;
            base.VisitToken(token);
        }
    }
}