﻿namespace CooperativeProcurement.Analyzers.Data
{
    public class ClassInfo
    {
        public string Name { get; set; } = string.Empty;
        public string FullName { get; set; } = string.Empty;
        public string Namespace { get; set; } = string.Empty;
        public List<string> Modifiers { get; set; } = new();
        public string BaseType { get; set; } = "object";
        public List<string> Interfaces { get; set; } = new();
        public List<MethodInfo> Methods { get; set; } = new();
        public List<PropertyInfo> Properties { get; set; } = new();
        public List<FieldInfo> Fields { get; set; } = new();
        public int Line { get; set; }
        public int MemberCount => Methods.Count + Properties.Count + Fields.Count;
        public string ProjectName { get; set; } = string.Empty;
        public string FilePath { get; set; } = string.Empty;
    }

   
    public class MethodInfo
    {
        public string Name { get; set; } = string.Empty;
        public string ReturnType { get; set; } = string.Empty;
        public List<string> Modifiers { get; set; } = new();
        public int Line { get; set; }
        public bool HasBody { get; set; }
        public bool IsAsync { get; set; }
        public bool IsStatic { get; set; }
        public bool IsPublic { get; set; }
        public List<string> Attributes { get; set; } = new();
        public List<ParameterInfo> Parameters { get; set; } = new();
        public int LineCount { get; set; }
        public int ComplexityScore { get; set; }
    }

    public class PropertyInfo
    {
        public string Name { get; set; } = string.Empty;
        public string Type { get; set; } = string.Empty;
        public List<string> Modifiers { get; set; } = new();
        public int Line { get; set; }
        public bool HasGetter { get; set; }
        public bool HasSetter { get; set; }
        public bool IsAutoProperty { get; set; }
    }

    public class FieldInfo
    {
        public string Name { get; set; } = string.Empty;
        public string Type { get; set; } = string.Empty;
        public List<string> Modifiers { get; set; } = new();
        public int Line { get; set; }
    }

    public class ParameterInfo
    {
        public string Name { get; set; } = string.Empty;
        public string Type { get; set; } = "var";
        public bool HasDefaultValue { get; set; }
        public string? DefaultValue { get; set; }
    }
}