﻿using System.Collections.Immutable;
using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp;
using Microsoft.CodeAnalysis.CSharp.Syntax;
using Microsoft.CodeAnalysis.Diagnostics;

namespace CooperativeProcurement.Analyzers.Analyzers
{
    [DiagnosticAnalyzer(LanguageNames.CSharp)]
    public class MethodCommentAnalyzer : DiagnosticAnalyzer
    {
        private const string DiagnosticId = "CP001";
        private const string Category = "Documentation";

        public static AnalysisMode Mode { get; set; } = AnalysisMode.Syntactic;

        private static readonly DiagnosticDescriptor Rule = new DiagnosticDescriptor(
            id: DiagnosticId,
            title: "Публичные методы должны иметь XML-комментарии",
            messageFormat: "Публичный метод '{0}' не содержит XML-комментарий (///<summary>...)",
            category: Category,
            defaultSeverity: DiagnosticSeverity.Warning,
            isEnabledByDefault: true,
            description: "Все публичные методы должны быть задокументированы с помощью XML-комментариев для улучшения читаемости и поддержки кода."
        );

        public override ImmutableArray<DiagnosticDescriptor> SupportedDiagnostics => ImmutableArray.Create(Rule);

        public override void Initialize(AnalysisContext context)
        {
            context.ConfigureGeneratedCodeAnalysis(GeneratedCodeAnalysisFlags.None);
            context.EnableConcurrentExecution();
            context.RegisterSyntaxNodeAction(AnalyzeMethod, SyntaxKind.MethodDeclaration);
        }

        private void AnalyzeMethod(SyntaxNodeAnalysisContext context)
        {
            switch (Mode)
            {
                case AnalysisMode.Syntactic:
                    AnalyzeMethodSyntactic(context);
                    break;
                case AnalysisMode.Semantic:
                    AnalyzeMethodSemantic(context);
                    break;
                default:
                    AnalyzeMethodSyntactic(context);
                    break;
            }
        }

        private void AnalyzeMethodSyntactic(SyntaxNodeAnalysisContext context)
        {
            var methodDeclaration = (MethodDeclarationSyntax)context.Node;

            var isPublic = methodDeclaration.Modifiers.Any(SyntaxKind.PublicKeyword);
            var isProtected = methodDeclaration.Modifiers.Any(SyntaxKind.ProtectedKeyword);
            var isInternal = methodDeclaration.Modifiers.Any(SyntaxKind.InternalKeyword);

            if (!isPublic && !isProtected && !isInternal)
                return;

            if (methodDeclaration.Modifiers.Any(SyntaxKind.OverrideKeyword))
                return;

            bool hasComment = HasXmlComment(methodDeclaration);

            if (!hasComment)
            {
                var diagnostic = Diagnostic.Create(
                    Rule,
                    methodDeclaration.Identifier.GetLocation(),
                    methodDeclaration.Identifier.Text
                );
                context.ReportDiagnostic(diagnostic);
            }
        }

        private void AnalyzeMethodSemantic(SyntaxNodeAnalysisContext context)
        {
            var methodDeclaration = (MethodDeclarationSyntax)context.Node;
            var semanticModel = context.SemanticModel;

            var methodSymbol = semanticModel.GetDeclaredSymbol(methodDeclaration);
            if (methodSymbol == null)
                return;

            if (methodSymbol.DeclaredAccessibility == Accessibility.Private)
                return;

            if (methodSymbol.IsOverride)
                return;

            var documentation = methodSymbol.GetDocumentationCommentXml();

            if (string.IsNullOrEmpty(documentation))
            {
                var diagnostic = Diagnostic.Create(
                    Rule,
                    methodDeclaration.Identifier.GetLocation(),
                    methodDeclaration.Identifier.Text
                );
                context.ReportDiagnostic(diagnostic);
            }
        }

        private bool HasXmlComment(MethodDeclarationSyntax method)
        {
            var leadingTrivia = method.GetLeadingTrivia();

            foreach (var trivia in leadingTrivia)
            {
                if (trivia.Kind() == SyntaxKind.SingleLineDocumentationCommentTrivia ||
                    trivia.Kind() == SyntaxKind.MultiLineDocumentationCommentTrivia)
                {
                    var structure = trivia.GetStructure();
                    if (structure != null)
                    {
                        var documentation = structure as DocumentationCommentTriviaSyntax;
                        if (documentation != null)
                        {
                            var hasSummary = documentation.Content
                                .OfType<XmlElementSyntax>()
                                .Any(e => e.StartTag.Name.ToString() == "summary");
                            if (hasSummary)
                                return true;
                        }
                    }
                }
            }

            return false;
        }
    }
}