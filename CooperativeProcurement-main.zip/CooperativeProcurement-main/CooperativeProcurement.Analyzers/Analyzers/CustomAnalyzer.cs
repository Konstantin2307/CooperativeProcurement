﻿using System.Collections.Immutable;
using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp;
using Microsoft.CodeAnalysis.CSharp.Syntax;
using Microsoft.CodeAnalysis.Diagnostics;

namespace CooperativeProcurement.Analyzers.Analyzers
{
    [DiagnosticAnalyzer(LanguageNames.CSharp)]
    public class CustomAnalyzer : DiagnosticAnalyzer
    {
        private const string DiagnosticId = "CP003";
        private const string Category = "CustomRules";

        private static readonly DiagnosticDescriptor Rule = new DiagnosticDescriptor(
            id: DiagnosticId,
            title: "Имена методов должны начинаться с заглавной буквы",
            messageFormat: "Метод '{0}' не начинается с заглавной буквы",
            category: Category,
            defaultSeverity: DiagnosticSeverity.Warning,
            isEnabledByDefault: true,
            description: "Все методы должны следовать соглашению об именовании PascalCase."
        );

        public override ImmutableArray<DiagnosticDescriptor> SupportedDiagnostics => ImmutableArray.Create(Rule);

        public override void Initialize(AnalysisContext context)
        {
            context.ConfigureGeneratedCodeAnalysis(GeneratedCodeAnalysisFlags.None);
            context.EnableConcurrentExecution();
            context.RegisterSyntaxNodeAction(AnalyzeNode, SyntaxKind.MethodDeclaration);
        }

        private void AnalyzeNode(SyntaxNodeAnalysisContext context)
        {
            var node = context.Node;
            var semanticModel = context.SemanticModel;

            if (node is MethodDeclarationSyntax method)
            {
                var name = method.Identifier.Text;
                if (!string.IsNullOrEmpty(name) && !char.IsUpper(name[0]))
                {
                    var diagnostic = Diagnostic.Create(
                        Rule,
                        method.Identifier.GetLocation(),
                        name
                    );
                    context.ReportDiagnostic(diagnostic);
                }
            }
        }
    }
}